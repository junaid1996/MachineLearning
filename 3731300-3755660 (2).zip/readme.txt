


Student names and ID�SJunaid Ahmed Syed - s3731300Harini Mylanahally Sannaveeranna - s3755660Steps to execute Assignment1.ipynb:� Download the dataset from the link https://archive.ics.uci.edu/ml/machine-learning-databases/wine-quality/winequality-red.csv.� Then go to Main menu->Kernel->Restart & Run All. This should make the entire file run except the line-6, this line shows no output. For that line to be executed - click on the line and press  Run button again. 